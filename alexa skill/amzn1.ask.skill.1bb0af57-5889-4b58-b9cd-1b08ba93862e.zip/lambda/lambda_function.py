# -*- coding: utf-8 -*-

# This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK for Python.
# Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
# session persistence, api calls, and more.
# This sample is built using the handler classes approach in skill builder.
import logging
import ask_sdk_core.utils as ask_utils

from ask_sdk_core.skill_builder import SkillBuilder
from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.dispatch_components import AbstractExceptionHandler
from ask_sdk_core.handler_input import HandlerInput

from ask_sdk_model import Response

import requests
import json

from utils import attribute_helper, deal_with_multi_value_slot

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class LaunchRequestHandler(AbstractRequestHandler):
    """Handler for Skill Launch."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool

        return ask_utils.is_request_type("LaunchRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Welcome, you can say Hello or Help. Which would you like to try?"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )


# class HelloWorldIntentHandler(AbstractRequestHandler):
#     """Handler for Hello World Intent."""
#     def can_handle(self, handler_input):
#         # type: (HandlerInput) -> bool
#         return ask_utils.is_intent_name("HelloWorldIntent")(handler_input)

#     def handle(self, handler_input):
#         # type: (HandlerInput) -> Response
#         speak_output = "Hello World!"

#         return (
#             handler_input.response_builder
#                 .speak(speak_output)
#                 # .ask("add a reprompt if you want to keep the session open for the user to respond")
#                 .response
#         )


class HelpIntentHandler(AbstractRequestHandler):
    """Handler for Help Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AMAZON.HelpIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "You can say hello to me! How can I help?"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )
        
    
class SelectIntentHandler(AbstractRequestHandler):
    """handler for select query"""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("SelectIntent")(handler_input)
        
    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        slots = handler_input.request_envelope.request.intent.slots
        
        #attributes slot is set as multi value, so the access to attribute slot is different from other slots
        attributes = slots["attribute"].slotValue
        if attributes["type"] == 'Simple':
            attributes = attributes["value"]
            attributes = attribute_helper(attributes)
        else:
            attribute_string = deal_with_multi_value_slot(attributes)
            # call attribute_helper to deal with attributes and return string
            attributes = attribute_helper(attribute_string)
        table = slots["table"].value
        
        sql = f'select {attributes} from {table}'
        
        # where clause
        if slots["where"].value:
            
            target_attribute = slots["target_attribute"].slotValue
            if target_attribute["type"] == 'Simple':
                target_attribute = target_attribute["value"]
            else:
                target_attribute_string = deal_with_multi_value_slot(target_attribute)
                # call attribute_helper to deal with target_attribute and return string
                target_attribute = attribute_helper(target_attribute_string)
                
            operator = slots["operator"].value
            target_attribute_value = slots["target_attribute_value"].value
            
            if operator in ["greater than","larger than","is greater than","is larger than"]:
                operator = '>'
            elif operator in ["smaller than","less than","is smaller than","is less than"]:
                operator = '<'
            elif operator in ["equal to","is","equals to"]:
                operator = '='
            elif operator in ["not equal to","is not","does not equal to"]:
                operator = '!='
            sql += f' where {target_attribute} {operator} {target_attribute_value}'
            
        # group by clause
        if slots["group_by"].value:
            group_by = slots["group_by"].value
            group_by_attribute = slots["group_by_attribute"].slotValue
            if group_by_attribute["type"] == 'Simple':
                group_by_attribute = group_by_attribute["value"]
            else:
                group_by_attribute_string = deal_with_multi_value_slot(group_by_attribute)
                # call attribute_helper to deal with target_attribute and return string
                group_by_attribute = attribute_helper(group_by_attribute_string)
                
            sql += f' {group_by} {group_by_attribute}'
        
        # limit clause    
        if slots["limit"].value:
            limit_number = slots["limit_number"].value
            sql += f' limit {limit_number}'
            
        sql += ';'
        
        speak_output = ''
        
        try:
            res = requests.get('http://18.211.73.183:5000/alexa', params={'query':sql})
            if res.status_code == requests.codes.ok:
                speak_output = 'sql is sent your web site, click display alexa input button to display'
            else:
                speak_output = f'there is error occuring with status code {res.status_code}, please try again'
                
        except Exception as e:
            speak_output = 'Can not connect to your web site, please check if the backend server started'
            
        #speak_output = 'haha test'
        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )


class ProductIntent(AbstractRequestHandler):
    """handler for find product info"""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("ProductIntent")(handler_input)
        
    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        slots = handler_input.request_envelope.request.intent.slots
        
        property = slots["property"].value
        if property in ['hot', 'popular', 'bought', 'purchased']:
            sql = 'select p.product_name, count(*) from instacart.products as p ' + \
                    'inner join instacart.order_products as op ' + \
                    'on p.product_id=op.product_id ' + \
                    'group by p.product_id order by count(*) ' + \
                    'desc ' + \
                    'limit 1;'
        elif property in ["reordered", "repurchased"]:
            sql = 'select distinct p.product_name from instacart.products as p ' + \
                    'inner join instacart.order_products as op ' + \
                    'on p.product_id=op.product_id ' + \
                    'order by op.reordered ' + \
                    'desc ' + \
                    'limit 1;'
                    
        speak_output = ''
            
        try:
            res = requests.get('http://18.211.73.183:5000/alexa', params={'query':sql})
            if res.status_code == requests.codes.ok:
                speak_output = 'sql is sent your web site, click display alexa input button to display'
            else:
                speak_output = f'there is error occuring with status code {res.status_code}, please try again'
                
        except Exception as e:
            speak_output = 'Can not connect to your web site, please check if the backend server started'
            
        #speak_output = 'haha test'
        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )


class CancelOrStopIntentHandler(AbstractRequestHandler):
    """Single handler for Cancel and Stop Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return (ask_utils.is_intent_name("AMAZON.CancelIntent")(handler_input) or
                ask_utils.is_intent_name("AMAZON.StopIntent")(handler_input))

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Goodbye!"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )


class SessionEndedRequestHandler(AbstractRequestHandler):
    """Handler for Session End."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("SessionEndedRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response

        # Any cleanup logic goes here.

        return handler_input.response_builder.response


class IntentReflectorHandler(AbstractRequestHandler):
    """The intent reflector is used for interaction model testing and debugging.
    It will simply repeat the intent the user said. You can create custom handlers
    for your intents by defining them above, then also adding them to the request
    handler chain below.
    """
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("IntentRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        intent_name = ask_utils.get_intent_name(handler_input)
        speak_output = "You just triggered " + intent_name + "."

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )


class CatchAllExceptionHandler(AbstractExceptionHandler):
    """Generic error handling to capture any syntax or routing errors. If you receive an error
    stating the request handler chain is not found, you have not implemented a handler for
    the intent being invoked or included it in the skill builder below.
    """
    def can_handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> bool
        return True

    def handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> Response
        logger.error(exception, exc_info=True)

        speak_output = "Sorry, I had trouble doing what you asked. Please try again."

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

# The SkillBuilder object acts as the entry point for your skill, routing all request and response
# payloads to the handlers above. Make sure any new handlers or interceptors you've
# defined are included below. The order matters - they're processed top to bottom.


sb = SkillBuilder()

sb.add_request_handler(LaunchRequestHandler())
sb.add_request_handler(ProductIntent())
sb.add_request_handler(SelectIntentHandler())
# sb.add_request_handler(HelloWorldIntentHandler())
sb.add_request_handler(HelpIntentHandler())
sb.add_request_handler(CancelOrStopIntentHandler())
sb.add_request_handler(SessionEndedRequestHandler())
sb.add_request_handler(IntentReflectorHandler()) # make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers

sb.add_exception_handler(CatchAllExceptionHandler())

lambda_handler = sb.lambda_handler()
import logging
import os
import boto3
from botocore.exceptions import ClientError


def create_presigned_url(object_name):
    """Generate a presigned URL to share an S3 object with a capped expiration of 60 seconds

    :param object_name: string
    :return: Presigned URL as string. If error, returns None.
    """
    s3_client = boto3.client('s3',
                             region_name=os.environ.get('S3_PERSISTENCE_REGION'),
                             config=boto3.session.Config(signature_version='s3v4',s3={'addressing_style': 'path'}))
    try:
        bucket_name = os.environ.get('S3_PERSISTENCE_BUCKET')
        response = s3_client.generate_presigned_url('get_object',
                                                    Params={'Bucket': bucket_name,
                                                            'Key': object_name},
                                                    ExpiresIn=60*1)
    except ClientError as e:
        logging.error(e)
        return None

    # The response contains the presigned URL
    return response


def attribute_helper(attributes):
    '''generate sql string for attributes part'''
    return_string = ""

    attributes = attributes.strip().split(' ')
    i = 0
    help_dic = {
        'aisle': {'id': ('aisle_id', 1)},
        'department': {'id': ('department_id', 1)},
        'product': {'id': ('product_id', 1), 'name': ('product_name', 1)},
        'user': {'id': ('user_id', 1)},
        'order': {'id': ('order_id', 1), 'number': ('order_number', 1), 'dow': ('order_dow', 1),
                  'hour': ('order_hour_of_day', 3)},
        'add': {'to': ('add_to_cart_order', 3)},
        'days': {'since': ('days_since_prior_order', 3)}
    }

    while i < len(attributes):
        if attributes[i] == 'star':
            return_string += ' *'

        elif (attributes[i] in help_dic) and (i + 1 < len(attributes)) and (
                attributes[i + 1] in help_dic[attributes[i]]):
            true_attribute_tuple = help_dic[attributes[i]][attributes[i + 1]]
            return_string += f' {true_attribute_tuple[0]}'
            i += true_attribute_tuple[1]

        else:
            return_string += f' {attributes[i]}'

        i += 1

    return_string = deal_with_aggregate(return_string)
    return return_string


def deal_with_aggregate(raw_string):
    aggregate_function = ['max', 'min', 'count', 'average']

    parsed_string = raw_string.strip().split(' ')
    i = 0
    final_string = ''

    while i < len(parsed_string):
        if parsed_string[i] in aggregate_function and i + 1 < len(parsed_string):
            if parsed_string[i] == 'average':
                final_string += f' avg({parsed_string[i + 1]})'
            else:
                final_string += f' {parsed_string[i]}({parsed_string[i + 1]})'
            i += 2

        else:
            final_string += f' {parsed_string[i]}'
            i += 1

        if i < len(parsed_string):
            final_string += ','

    return final_string


def deal_with_multi_value_slot(slotValues):
    value_string = ''
    # for i in range(0, len(slotValues.values)):
    #     value_string += slotValues.values[i].value
    for elem in slotValues["values"]:
        value_string += elem["value"]
        value_string += ' '
    return value_string
    
    